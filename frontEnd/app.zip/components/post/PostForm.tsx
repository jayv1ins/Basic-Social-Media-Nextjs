'use client'

import { useState } from 'react'
import axios from 'axios'
import toast from 'react-hot-toast'
const apiUrl = process.env.NEXT_PUBLIC_API_URL;

type Post = {
  title: string
  content: string
}

export default function PostForm() {
  const [post, setPost] = useState<Post>({
    title: '',
    content: '',
  })
  const [postFiles, setPostFiles] = useState<File[]>([])

  const handleChange = (field: keyof Post) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setPost({ ...post, [field]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const formData = new FormData()
    formData.append('title', post.title)
    formData.append('content', post.content)

    postFiles.forEach((file, index) => {
      formData.append(`thumbnail[]`, file) // for array-style handling in Laravel
    })

    try {
      await axios.post('http://localhost:8000/api/posts', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })

      // alert('Post created!')
      toast.success('Post created successfully!')
      setPost({ title: '', content: '' })
      setPostFiles([])
    } catch (error: any) {
      const msg = error.response?.data?.message || 'Unknown error'
      toast.error(`Failed: ${msg}`)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded shadow">
      <input
        type="text"
        className="w-full border p-2 rounded"
        placeholder="title"
        value={post.title}
        onChange={handleChange('title')}
      />
      <input
        type="file"
        className="w-full border p-2 rounded"
        multiple
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            setPostFiles(Array.from(e.target.files))
          }
        }}
      />
      
      <textarea
        className="w-full border p-2 rounded"
        placeholder="Content"
        value={post.content}
        onChange={handleChange('content')}
        required
      />
      <button type="submit" className="bg-black text-white px-4 py-2 rounded">
        Create Post
      </button>
    </form>
  )
}
