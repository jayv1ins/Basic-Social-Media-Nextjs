'use client'

import { usePathname, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import clsx from 'clsx'
import axios from 'axios'

const apiUrl = process.env.NEXT_PUBLIC_API_URL

interface User {
  id: number
  email: string
  username: string
}

export default function Navbar() {
  const pathname = usePathname()
  const router = useRouter()

  const [user, setUser] = useState<User | null>(null)
  const [hasMounted, setHasMounted] = useState(false)

  useEffect(() => {
    setHasMounted(true)

    const token = localStorage.getItem('token')
    if (!token) return

    axios
      .get(`${apiUrl}/user`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then(response => {
        const userData: User = response.data
        setUser(userData)
      })
      .catch(error => {
        console.error('❌ Error fetching user:', error)
        setUser(null)
      })
  }, [])

  const handleLogout = () => {
    localStorage.removeItem('token')
    setUser(null)

    axios
    .post(`${apiUrl}/logout`)
    .then(response => {
      console.log('✅ Logout successful:', response.data)})
      
    .catch(error => {
      console.error('❌ Error fetching user:', error)
      setUser(null)
    })
    router.push('/login')
  }

  const navItems = [
    { name: 'Home', path: '/feed' },
    { name: 'About', path: '/about' },
    { name: 'Profile', path: '/profile' },
  ]

  if (!hasMounted) return null

  return (
    <nav className="w-full py-4 px-6 flex justify-between items-center border-b">
      <Link href="/" className="font-bold text-xl text-[#800000]">
        {user ? user.username : 'Incognitor'}
      </Link>

      <div className="space-x-6 flex items-center">
        {navItems.map(item => (
          <Link
            key={item.name}
            href={item.path}
            className={clsx(
              'transition-colors duration-200 border-b-2 pb-1',
              pathname === item.path
                ? 'text-[#800000] border-[#800000]'
                : 'text-black border-transparent hover:text-[#800000] hover:border-[#800000]'
            )}
          >
            {item.name}
          </Link>
        ))}

        {user && (
          <button
            onClick={handleLogout}
            className="text-black hover:text-[#800000] transition-colors duration-200"
          >
            Logout
          </button>
        )}
      </div>
    </nav>
  )
}
