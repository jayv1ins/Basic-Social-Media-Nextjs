// import PostForm from '@/components/post/PostForm'
// import PostList from '@/components/post/PostList'
import EditPostForm from "@/components/post/EditForm"

export default function EditPostPage({ params }: { params: { slug: string } }) {
  return (
    <main className="max-w-xl mx-auto py-8">
      <h1 className="text-3xl font-bold mb-4 text-center">Update</h1>
      <EditPostForm slug={params.slug} />
    </main>
  )
}
