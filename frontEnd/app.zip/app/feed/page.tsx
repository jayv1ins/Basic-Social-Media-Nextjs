// app/page.tsx
import PostForm from '@/components/post/PostForm'
import PostList from '@/components/post/PostList'

export default function HomePage() {
  return (
    <main className="max-w-xl mx-auto py-8">
      <h1 className="text-3xl font-bold mb-4 text-center">Incognitor</h1>
      <PostForm />
      <PostList />
    </main>
  )
}
