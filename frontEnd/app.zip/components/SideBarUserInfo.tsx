'use client'

import { useEffect, useState } from 'react'
import axios from 'axios'
import Link from 'next/link'

const apiUrl = process.env.NEXT_PUBLIC_API_URL

interface Post {
  id: number
  slug: string
  excerpt: string
  content: string
}

interface User {
  id: number
  username: string
  email: string
  avatar?: string
}

export default function ProfilePage() {
  const [user, setUser] = useState<User | null>(null)
  const [posts, setPosts] = useState<Post[]>([])

  useEffect(() => {
    const token = localStorage.getItem('token')


    // Fetch user profile
    axios
    .get(`${apiUrl}/user`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    .then(response => {
      const userData: User = response.data
      setUser(userData)
    })
    .catch(error => {
      console.error('❌ Error fetching user:', error)
      setUser(null)
    })
      
    // Fetch user's posts
  //   axios
  //     .get(`${apiUrl}/myPost`, {
  //       headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
  //     })
  //     .then(res => setPosts(res.data.data))
  }, [])

  if (!user) return <div className="text-center mt-10">Loading profile...</div>

  return (
    <div className="flex px-6 py-10">
      {/* Left: Avatar + Info */}
      <div className="w-[250px] border p-4 rounded shadow bg-white">
        <img
          src={user.avatar || '/default-avatar.png'}
          alt="Avatar"
          className="w-32 h-32 rounded-full mx-auto mb-4"
        />
        <h2 className="text-center font-bold text-lg">{user.username}</h2>
        <p className="text-center text-sm text-gray-600">{user.email}</p>

        <div className="mt-6 text-center">
          <Link
            href="/profile/edit/"
            className="inline-block px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
          >
            Edit Profile
          </Link>
        </div>
      </div>

    
    </div>
  )
}
