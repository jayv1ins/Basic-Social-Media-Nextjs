'use client'

import { useEffect, useState } from 'react'
import axios from 'axios'
import toast from 'react-hot-toast'
import { useRouter } from 'next/navigation'

const apiUrl = process.env.NEXT_PUBLIC_API_URL

interface User {
  id: number
  username: string
  email: string
  avatar?: string
}

export default function EditProfilePage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [avatarFile, setAvatarFile] = useState<File | null>(null)

  useEffect(() => {
    const token = localStorage.getItem('token')

    axios
      .get(`${apiUrl}/user`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then(res => setUser(res.data))
      .catch(err => {
        toast.error('Failed to load user.')
        setUser(null)
      })
  }, [])

  const getFileUrl = (path: string) => {
    return path.startsWith('http') ? path : `${apiUrl?.replace('/api', '')}/storage/${path}`
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!user) return
    const { name, value } = e.target
    setUser({ ...user, [name]: value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const token = localStorage.getItem('token')
    const formData = new FormData()

    if (user?.username) formData.append('username', user.username)
    if (user?.email) formData.append('email', user.email)
    if (avatarFile) formData.append('avatar', avatarFile)

    try {
      await axios.put(`${apiUrl}/profile/update`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      })

      toast.success('Profile updated!')
      router.push('/profile')
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Update failed'
      toast.error(msg)
    }
  }

  if (!user) return <div className="text-center mt-10">Loading profile...</div>

  return (
    <main className="max-w-xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold mb-6 text-center">Edit Profile</h1>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow space-y-4">
        <div className="text-center">
          <img
            src={
              avatarFile
                ? URL.createObjectURL(avatarFile)
                : user.avatar
                ? getFileUrl(user.avatar)
                : '/default-avatar.png'
            }
            alt="Avatar"
            className="w-24 h-24 rounded-full mx-auto object-cover mb-4"
          />
          <input
            type="file"
            accept="image/*"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                setAvatarFile(e.target.files[0])
              }
            }}
          />
        </div>

        <input
          name="username"
          type="text"
          value={user.username}
          onChange={handleChange}
          className="w-full border p-2 rounded"
          placeholder="Username"
        />

        <input
          name="email"
          type="email"
          value={user.email}
          onChange={handleChange}
          className="w-full border p-2 rounded"
          placeholder="Email"
        />

        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
          Save Changes
        </button>
      </form>
    </main>
  )
}
