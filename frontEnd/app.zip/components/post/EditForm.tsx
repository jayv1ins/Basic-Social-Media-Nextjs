'use client'

import { useEffect, useState } from 'react'
import axios from 'axios'
import toast from 'react-hot-toast'
import { useRouter } from 'next/navigation'

const apiUrl = process.env.NEXT_PUBLIC_API_URL

type Post = {
  title: string
  content: string
}

export default function EditPostForm({ slug }: { slug: string }) {
  const [post, setPost] = useState<Post>({ title: '', content: '' })
  const [postFiles, setPostFiles] = useState<File[]>([])
  const [existingThumbs, setExistingThumbs] = useState<string[]>([])
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('token')

    axios
      .get(`${apiUrl}/edit/${slug}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => {
        const { title, content, thumbnail } = res.data.data
        setPost({ title, content })
        if (thumbnail) {
          const thumbs = thumbnail.split(',').map((t: string) => t.trim())
          setExistingThumbs(thumbs)
        }
      })
      .catch(() => {
        toast.error('Failed to load post')
        router.push('/feed')
      })
  }, [slug])

  const handleChange = (field: keyof Post) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setPost({ ...post, [field]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const token = localStorage.getItem('token')
    const formData = new FormData()
    formData.append('title', post.title)
    formData.append('content', post.content)

    postFiles.forEach((file) => {
      formData.append(`thumbnail[]`, file)
    })

    try {
      await axios.post(`${apiUrl}/edit/${slug}?_method=PUT`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      }).then((res) => {
        console.log('Post updated:', res.data)
      })

      toast.success('Post updated successfully!')
      router.push('/feed')
    } catch (error: any) {
      const msg = error.response?.data?.message || 'Unknown error'
      toast.error(`Failed: ${msg}`)
    }
  }

  const getFileUrl = (path: string) =>
    path.startsWith('http') ? path : `${apiUrl?.replace('/api', '')}/storage/${path}`

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded shadow">
      <input
        type="text"
        className="w-full border p-2 rounded"
        placeholder="Title"
        value={post.title}
        onChange={handleChange('title')}
      />

      {/* ✅ Preview existing thumbnails */}
      {existingThumbs.length > 0 && (
        <div className="flex gap-4 flex-wrap">
          {existingThumbs.map((path, idx) => (
            <img
              key={idx}
              src={getFileUrl(path)}
              alt={`thumb-${idx}`}
              className="w-24 h-24 rounded border object-cover"
            />
          ))}
        </div>
      )}

      <input
        type="file"
        className="w-full border p-2 rounded"
        multiple
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            setPostFiles(Array.from(e.target.files))
          }
        }}
      />

      <textarea
        className="w-full border p-2 rounded"
        placeholder="Content"
        value={post.content}
        onChange={handleChange('content')}
        required
      />
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
        Update Post
      </button>
    </form>
  )
}
